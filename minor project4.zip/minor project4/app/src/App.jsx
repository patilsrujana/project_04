
import { useState } from "react";
import "./index.css";

function App() {
  const [task, setTask] = useState("");
  const [tasks, setTasks] = useState([]);

  const [note, setNote] = useState("");
  const [notes, setNotes] = useState([]);

  function addTask() {
    if (task.trim() === "") return;

    setTasks([...tasks, task]);
    setTask("");
  }

  function deleteTask(index) {
    setTasks(tasks.filter((item, i) => i !== index));
  }

  function addNote() {
    if (note.trim() === "") return;

    setNotes([...notes, note]);
    setNote("");
  }

  function deleteNote(index) {
    setNotes(notes.filter((item, i) => i !== index));
  }

  return (
    <div className="app">
      <h1>My Productivity App</h1>

      <div className="section">
        <h2>My To-Do List</h2>

        <input
          value={task}
          onChange={(e) => setTask(e.target.value)}
          placeholder="Enter a task"
        />

        <button onClick={addTask}>Add Task</button>

        {tasks.map((item, index) => (
          <p key={index}>
            {item}
            <button onClick={() => deleteTask(index)}>
              Delete
            </button>
          </p>
        ))}
      </div>

      <div className="section">
        <h2>My Notes</h2>

        <textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Write your note"
        />

        <br />

        <button onClick={addNote}>Add Note</button>

        {notes.map((item, index) => (
          <p key={index}>
            {item}
            <button onClick={() => deleteNote(index)}>
              Delete
            </button>
          </p>
        ))}
      </div>
    </div>
  );
}

export default App;
